<?php

/**
 * Database config variables
 */
	define("DB_HOST", "localhost");
	define("DB_USER", "id2558345_root");
	define("DB_PASSWORD", "korea0504");
	define("DB_DATABASE", "id2558345_kiki");
?>
